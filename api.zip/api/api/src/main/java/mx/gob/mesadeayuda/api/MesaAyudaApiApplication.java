package mx.gob.mesadeayuda.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MesaAyudaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MesaAyudaApiApplication.class, args);
	}

}
