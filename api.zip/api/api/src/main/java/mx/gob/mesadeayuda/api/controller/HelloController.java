package mx.gob.mesadeayuda.api.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
@Tag(name = "Controlador de ejemplo", description = "Prueba inicial del entorno")
public class HelloController {

    @Operation(
            summary = "Saludo de prueba",
            description = "Devuelve el texto 'OK' para confirmar que el sistema está en funcionamiento."
    )
    @GetMapping("/hello")
    public String hello() {
        return "OK";
    }
}
